import type { BatchTransport, OperationBatchResult, OperationEnvelope } from "./types.js";

export type SyncFault = "OFFLINE" | "TIMEOUT" | "HTTP_500" | "HTTP_401" | "GOOGLE_ERROR" | "EMAIL_ERROR" | "CONFLICT" | "NONE";

export class OrbitSyncTestHarness implements BatchTransport {
  private fault: SyncFault = "NONE";
  readonly received: OperationEnvelope[][] = [];
  readonly appliedIdempotencyKeys = new Set<string>();

  setFault(fault: SyncFault) { this.fault = fault; }

  async send(operations: readonly OperationEnvelope[]): Promise<readonly OperationBatchResult[]> {
    this.received.push(operations.map((operation) => structuredClone(operation)));
    if (["OFFLINE", "TIMEOUT", "HTTP_500"].includes(this.fault)) throw new Error(this.fault);
    return operations.map((operation) => {
      if (this.fault === "HTTP_401") return { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status: "BLOCKED", error_code: "AUTH_EXPIRED" };
      if (this.fault === "GOOGLE_ERROR") return { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status: "ERROR", error_code: "GOOGLE_DOWN", retryable: true };
      if (this.fault === "EMAIL_ERROR") return { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status: "ERROR", error_code: "EMAIL_DOWN", retryable: true };
      if (this.fault === "CONFLICT") return { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status: "CONFLICT", error_code: "VERSION_CONFLICT", server_version: (operation.base_version ?? 0) + 1 };
      const duplicate = this.appliedIdempotencyKeys.has(operation.idempotency_key);
      this.appliedIdempotencyKeys.add(operation.idempotency_key);
      return { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status: "SUCCESS", resource_server_id: operation.resource_server_id ?? operation.resource_local_id, server_version: duplicate ? operation.base_version ?? 1 : (operation.base_version ?? 0) + 1 };
    });
  }
}
