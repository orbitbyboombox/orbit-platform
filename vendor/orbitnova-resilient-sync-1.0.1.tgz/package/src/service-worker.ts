const SAFE_METHODS = new Set(["GET"]);

export function isSafeShellCacheRequest(request: Request, appOrigin: string) {
  const url = new URL(request.url);
  if (!SAFE_METHODS.has(request.method) || url.origin !== appOrigin) return false;
  if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/auth/") || url.search) return false;
  return ["document", "script", "style", "font", "image"].includes(request.destination);
}

export async function registerOrbitSyncServiceWorker(path = "/orbit-resilient-sync-sw.js") {
  if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return null;
  return navigator.serviceWorker.register(path, { scope: "/" });
}

export const ORBIT_BACKGROUND_SYNC_TAG = "orbit-resilient-sync";
