export const RETRY_DELAYS_MS = [60_000, 300_000, 900_000, 3_600_000] as const;

export type RetryDecision = {
  retry: boolean;
  manual: boolean;
  delayMs: number | null;
  nextAttemptAt: string | null;
};

export function retryDecision(retryCount: number, now = new Date(), random = Math.random): RetryDecision {
  const base = RETRY_DELAYS_MS[retryCount];
  if (base === undefined) return { retry: false, manual: true, delayMs: null, nextAttemptAt: null };
  const jitter = Math.round(base * 0.2 * ((random() * 2) - 1));
  const delayMs = Math.max(1_000, base + jitter);
  return { retry: true, manual: false, delayMs, nextAttemptAt: new Date(now.getTime() + delayMs).toISOString() };
}
