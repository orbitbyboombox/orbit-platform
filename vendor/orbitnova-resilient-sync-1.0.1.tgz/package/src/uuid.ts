export function randomUUID() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  throw new Error("SECURE_UUID_UNAVAILABLE");
}
