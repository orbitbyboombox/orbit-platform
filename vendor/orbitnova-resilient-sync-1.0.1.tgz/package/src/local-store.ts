import type { BlobRecord, OperationEnvelope, OperationSyncStatus, ResourceIdMapping } from "./types.js";

export type OrbitLocalStore = {
  putOperation(operation: OperationEnvelope): Promise<void>;
  getOperation(operationId: string): Promise<OperationEnvelope | null>;
  listOperations(statuses?: readonly OperationSyncStatus[]): Promise<OperationEnvelope[]>;
  deleteOperation(operationId: string): Promise<void>;
  putBlob(record: BlobRecord): Promise<void>;
  getBlob(blobId: string): Promise<BlobRecord | null>;
  listBlobs(): Promise<BlobRecord[]>;
  deleteBlob(blobId: string): Promise<void>;
  putMapping(mapping: ResourceIdMapping): Promise<void>;
  getMapping(resourceLocalId: string): Promise<ResourceIdMapping | null>;
  clearUserData(): Promise<void>;
};

type ScopedRecord = { organization_id: string; actor_user_id: string };
const DB_VERSION = 1;

export class IndexedDbOrbitLocalStore implements OrbitLocalStore {
  private dbPromise: Promise<IDBDatabase> | null = null;

  constructor(private readonly organizationId: string, private readonly actorUserId: string, private readonly indexedDb: IDBFactory = indexedDB) {}

  private databaseName() {
    return `orbit-resilient-sync-v1:${this.organizationId}:${this.actorUserId}`;
  }

  private assertScope(value: ScopedRecord) {
    if (value.organization_id !== this.organizationId || value.actor_user_id !== this.actorUserId) throw new Error("CROSS_TENANT_BLOCKED");
  }

  private db() {
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise((resolve, reject) => {
      const request = this.indexedDb.open(this.databaseName(), DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains("operations")) db.createObjectStore("operations", { keyPath: "operation_id" });
        if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs", { keyPath: "blob_id" });
        if (!db.objectStoreNames.contains("mappings")) db.createObjectStore("mappings", { keyPath: "resource_local_id" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("INDEXEDDB_OPEN_FAILED"));
    });
    return this.dbPromise;
  }

  private async request<T>(storeName: string, mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>) {
    const db = await this.db();
    return new Promise<T>((resolve, reject) => {
      const transaction = db.transaction(storeName, mode);
      const request = run(transaction.objectStore(storeName));
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("INDEXEDDB_REQUEST_FAILED"));
      transaction.onabort = () => reject(transaction.error ?? new Error("INDEXEDDB_TRANSACTION_ABORTED"));
    });
  }

  async putOperation(operation: OperationEnvelope) { this.assertScope(operation); await this.request("operations", "readwrite", (store) => store.put(operation)); }
  async getOperation(operationId: string) { const value = await this.request<OperationEnvelope | undefined>("operations", "readonly", (store) => store.get(operationId)); return value ?? null; }
  async listOperations(statuses?: readonly OperationSyncStatus[]) {
    const values = await this.request<OperationEnvelope[]>("operations", "readonly", (store) => store.getAll());
    return values.filter((value) => value.organization_id === this.organizationId && value.actor_user_id === this.actorUserId && (!statuses || statuses.includes(value.sync_status))).sort((a, b) => a.queued_at.localeCompare(b.queued_at));
  }
  async deleteOperation(operationId: string) { await this.request("operations", "readwrite", (store) => store.delete(operationId)); }
  async putBlob(record: BlobRecord) { this.assertScope(record); await this.request("blobs", "readwrite", (store) => store.put(record)); }
  async getBlob(blobId: string) { const value = await this.request<BlobRecord | undefined>("blobs", "readonly", (store) => store.get(blobId)); return value ?? null; }
  async listBlobs() { const values = await this.request<BlobRecord[]>("blobs", "readonly", (store) => store.getAll()); return values.filter((value) => value.organization_id === this.organizationId && value.actor_user_id === this.actorUserId).sort((a, b) => a.created_at.localeCompare(b.created_at)); }
  async deleteBlob(blobId: string) { await this.request("blobs", "readwrite", (store) => store.delete(blobId)); }
  async putMapping(mapping: ResourceIdMapping) { this.assertScope(mapping); await this.request("mappings", "readwrite", (store) => store.put(mapping)); }
  async getMapping(resourceLocalId: string) { const value = await this.request<ResourceIdMapping | undefined>("mappings", "readonly", (store) => store.get(resourceLocalId)); return value ?? null; }
  async clearUserData() {
    const db = await this.dbPromise;
    db?.close();
    this.dbPromise = null;
    await new Promise<void>((resolve, reject) => {
      const request = this.indexedDb.deleteDatabase(this.databaseName());
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error ?? new Error("INDEXEDDB_CLEAR_FAILED"));
      request.onblocked = () => reject(new Error("INDEXEDDB_CLEAR_BLOCKED"));
    });
  }
}

export class MemoryOrbitLocalStore implements OrbitLocalStore {
  private operations = new Map<string, OperationEnvelope>();
  private blobs = new Map<string, BlobRecord>();
  private mappings = new Map<string, ResourceIdMapping>();
  constructor(private readonly organizationId: string, private readonly actorUserId: string) {}
  private assertScope(value: ScopedRecord) { if (value.organization_id !== this.organizationId || value.actor_user_id !== this.actorUserId) throw new Error("CROSS_TENANT_BLOCKED"); }
  async putOperation(value: OperationEnvelope) { this.assertScope(value); this.operations.set(value.operation_id, structuredClone(value)); }
  async getOperation(id: string) { return structuredClone(this.operations.get(id) ?? null); }
  async listOperations(statuses?: readonly OperationSyncStatus[]) { return [...this.operations.values()].filter((value) => !statuses || statuses.includes(value.sync_status)).sort((a, b) => a.queued_at.localeCompare(b.queued_at)).map((value) => structuredClone(value)); }
  async deleteOperation(id: string) { this.operations.delete(id); }
  async putBlob(value: BlobRecord) { this.assertScope(value); this.blobs.set(value.blob_id, value); }
  async getBlob(id: string) { return this.blobs.get(id) ?? null; }
  async listBlobs() { return [...this.blobs.values()].sort((a, b) => a.created_at.localeCompare(b.created_at)); }
  async deleteBlob(id: string) { this.blobs.delete(id); }
  async putMapping(value: ResourceIdMapping) { this.assertScope(value); this.mappings.set(value.resource_local_id, structuredClone(value)); }
  async getMapping(id: string) { return structuredClone(this.mappings.get(id) ?? null); }
  async clearUserData() { this.operations.clear(); this.blobs.clear(); this.mappings.clear(); }
}
