import type { ExternalJobEnvelope, JsonObject, OfflineResourceType, OperationBatchResult, OperationEnvelope } from "./types.js";
import { assertEnvelopeScope, assertOperationEnvelope, safeSyncMessage } from "./validation.js";
import { retryDecision } from "./retry.js";

export type SyncActorContext = { organizationId: string; actorUserId: string; role: string; clientSlug: string; accessToken?: string };
export type PersistedOperation = OperationEnvelope & { result: OperationBatchResult | null };
export type OperationRepository = {
  findByIdempotency(organizationId: string, idempotencyKey: string): Promise<PersistedOperation | null>;
  insert(operation: OperationEnvelope): Promise<{ row: PersistedOperation; inserted: boolean }>;
  complete(organizationId: string, operationId: string, result: OperationBatchResult): Promise<void>;
};
export type ResourceMutationResult = { resourceServerId: string; version: number; snapshot?: JsonObject };
export type ResourceAdapter = {
  create(operation: OperationEnvelope, context: SyncActorContext): Promise<ResourceMutationResult>;
  update(operation: OperationEnvelope, context: SyncActorContext): Promise<ResourceMutationResult>;
  archive?(operation: OperationEnvelope, context: SyncActorContext): Promise<ResourceMutationResult>;
};
export type ResourceAdapterRegistry = Partial<Record<OfflineResourceType, ResourceAdapter>>;

export class ResourceConflictError extends Error {
  constructor(
    readonly serverVersion: number,
    readonly serverSnapshot: JsonObject,
  ) {
    super("VERSION_CONFLICT");
  }
}

function persistedResult(row: PersistedOperation): OperationBatchResult {
  if (row.result) return row.result;
  if (row.sync_status === "CONFLICT") return { operation_id: row.operation_id, idempotency_key: row.idempotency_key, status: "CONFLICT", error_code: row.last_error_code ?? "CONFLICT", safe_message: safeSyncMessage("CONFLICT") };
  if (row.sync_status === "BLOCKED") return { operation_id: row.operation_id, idempotency_key: row.idempotency_key, status: "BLOCKED", error_code: row.last_error_code ?? "BLOCKED", safe_message: safeSyncMessage(row.last_error_code ?? "BLOCKED") };
  return { operation_id: row.operation_id, idempotency_key: row.idempotency_key, status: "ERROR", error_code: row.last_error_code ?? "OPERATION_PENDING", safe_message: safeSyncMessage(row.last_error_code ?? "OPERATION_PENDING"), retryable: true };
}

export async function processSyncBatch(context: SyncActorContext, operations: readonly OperationEnvelope[], repository: OperationRepository, adapters: ResourceAdapterRegistry) {
  if (operations.length < 1 || operations.length > 100) throw new Error("INVALID_BATCH_SIZE");
  const results: OperationBatchResult[] = [];
  for (const operation of operations) {
    let claimed = false;
    try {
      assertOperationEnvelope(operation);
      assertEnvelopeScope(operation, context.organizationId, context.actorUserId);
      const existing = await repository.findByIdempotency(context.organizationId, operation.idempotency_key);
      if (existing) {
        if (existing.actor_user_id !== context.actorUserId) throw new Error("IDEMPOTENCY_ACTOR_MISMATCH");
        results.push(persistedResult(existing)); continue;
      }
      const receipt = await repository.insert(operation);
      if (!receipt.inserted) {
        if (receipt.row.actor_user_id !== context.actorUserId) throw new Error("IDEMPOTENCY_ACTOR_MISMATCH");
        results.push(persistedResult(receipt.row)); continue;
      }
      claimed = true;
      const adapter = adapters[operation.resource_type];
      if (!adapter) {
        const result: OperationBatchResult = { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status: "BLOCKED", error_code: "ADAPTER_NOT_CONFIGURED", safe_message: safeSyncMessage("ADAPTER_NOT_CONFIGURED") };
        await repository.complete(context.organizationId, operation.operation_id, result); results.push(result); continue;
      }
      const applied = operation.action === "CREATE" ? await adapter.create(operation, context) : operation.action === "UPDATE" ? await adapter.update(operation, context) : adapter.archive ? await adapter.archive(operation, context) : null;
      if (!applied) throw new Error("ARCHIVE_NOT_SUPPORTED");
      const result: OperationBatchResult = { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status: "SUCCESS", resource_server_id: applied.resourceServerId, server_version: applied.version, server_snapshot: applied.snapshot };
      await repository.complete(context.organizationId, operation.operation_id, result); results.push(result);
    } catch (error) {
      const code = error instanceof Error ? error.message : "SYNC_OPERATION_FAILED";
      const status = code === "VERSION_CONFLICT" ? "CONFLICT" : code === "CROSS_TENANT_BLOCKED" || code === "ACTOR_MISMATCH" || code === "IDEMPOTENCY_ACTOR_MISMATCH" ? "BLOCKED" : "ERROR";
      const result: OperationBatchResult = { operation_id: operation.operation_id, idempotency_key: operation.idempotency_key, status, error_code: code, safe_message: safeSyncMessage(status === "CONFLICT" ? "CONFLICT" : code), retryable: status === "ERROR", ...(error instanceof ResourceConflictError ? { server_version: error.serverVersion, server_snapshot: error.serverSnapshot } : {}) };
      if (claimed) await repository.complete(context.organizationId, operation.operation_id, result).catch(() => undefined);
      results.push(result);
    }
  }
  return results;
}

export type ExternalJobRepository = {
  claimNext(now: Date): Promise<ExternalJobEnvelope | null>;
  succeed(jobId: string, result: JsonObject): Promise<void>;
  reschedule(jobId: string, retryCount: number, nextAttemptAt: string, errorCode: string): Promise<void>;
  fail(jobId: string, status: "FAILED" | "BLOCKED_AUTH", errorCode: string): Promise<void>;
};
export type ExternalJobAdapter = { execute(job: ExternalJobEnvelope): Promise<JsonObject> };
export type ExternalJobAdapters = Partial<Record<ExternalJobEnvelope["job_type"], ExternalJobAdapter>>;

export async function processNextExternalJob(repository: ExternalJobRepository, adapters: ExternalJobAdapters, now = new Date()) {
  const job = await repository.claimNext(now);
  if (!job) return null;
  const adapter = adapters[job.job_type];
  if (!adapter) { await repository.fail(job.job_id, "FAILED", "ADAPTER_NOT_CONFIGURED"); return { jobId: job.job_id, status: "FAILED" as const }; }
  try {
    const result = await adapter.execute(job);
    await repository.succeed(job.job_id, result);
    return { jobId: job.job_id, status: "SUCCESS" as const };
  } catch (error) {
    const code = error instanceof Error ? error.message : "EXTERNAL_JOB_FAILED";
    if (code === "BLOCKED_AUTH" || code === "RECONNECT_REQUIRED") {
      await repository.fail(job.job_id, "BLOCKED_AUTH", code);
      return { jobId: job.job_id, status: "BLOCKED_AUTH" as const };
    }
    const retry = retryDecision(job.retry_count, now);
    if (!retry.retry || !retry.nextAttemptAt) {
      await repository.fail(job.job_id, "FAILED", code);
      return { jobId: job.job_id, status: "FAILED" as const };
    }
    await repository.reschedule(job.job_id, job.retry_count + 1, retry.nextAttemptAt, code);
    return { jobId: job.job_id, status: "RETRYING" as const, nextAttemptAt: retry.nextAttemptAt };
  }
}
