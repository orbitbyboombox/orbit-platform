import type { FileUploadTransport } from "./types.js";
import type { OrbitLocalStore } from "./local-store.js";
import { randomUUID } from "./uuid.js";

export class OrbitOfflineFileQueue {
  private active: Promise<{ uploaded: number; errors: number }> | null = null;
  constructor(private readonly organizationId: string, private readonly actorUserId: string, private readonly store: OrbitLocalStore, private readonly transport: FileUploadTransport) {}

  async enqueue(input: { operationId: string; filename: string; mimeType: string; blob: Blob }) {
    if (!input.filename.trim() || !input.mimeType.trim() || input.blob.size < 1) throw new Error("INVALID_OFFLINE_FILE");
    const record = { blob_id: randomUUID(), organization_id: this.organizationId, actor_user_id: this.actorUserId, operation_id: input.operationId, filename: input.filename, mime_type: input.mimeType, size: input.blob.size, blob: input.blob, upload_status: "PENDING" as const, retry_count: 0, last_error_at: null, server_reference: null, created_at: new Date().toISOString() };
    await this.store.putBlob(record);
    return record;
  }

  syncNow() {
    if (this.active) return this.active;
    this.active = this.run().finally(() => { this.active = null; });
    return this.active;
  }

  private async run() {
    const records = (await this.store.listBlobs()).filter((record) => (record.upload_status === "PENDING" || record.upload_status === "ERROR") && record.retry_count < 4);
    let uploaded = 0;
    let errors = 0;
    for (const record of records) {
      await this.store.putBlob({ ...record, upload_status: "UPLOADING" });
      try {
        const result = await this.transport.upload(record);
        if (!result.serverReference) throw new Error("FILE_REFERENCE_MISSING");
        await this.store.putBlob({ ...record, upload_status: "UPLOADED", server_reference: result.serverReference, last_error_at: null });
        uploaded += 1;
      } catch {
        const retryCount = record.retry_count + 1;
        await this.store.putBlob({ ...record, upload_status: retryCount >= 4 ? "BLOCKED" : "ERROR", retry_count: retryCount, last_error_at: new Date().toISOString() });
        errors += 1;
      }
    }
    return { uploaded, errors };
  }

  async releaseUploaded(blobId: string) {
    const record = await this.store.getBlob(blobId);
    if (!record || record.upload_status !== "UPLOADED" || !record.server_reference) throw new Error("FILE_NOT_UPLOADED");
    await this.store.deleteBlob(blobId);
  }

  async retry(blobId: string) {
    const record = await this.store.getBlob(blobId);
    if (!record || (record.upload_status !== "ERROR" && record.upload_status !== "BLOCKED")) throw new Error("FILE_RETRY_NOT_ALLOWED");
    await this.store.putBlob({ ...record, upload_status: "PENDING", retry_count: 0, last_error_at: null });
    return this.syncNow();
  }
}
