export const OFFLINE_RESOURCE_TYPES = [
  "CLIENT",
  "QUOTE_DRAFT",
  "RESERVATION_DRAFT",
  "EVENT_DRAFT",
  "EXPENSE",
  "NOTE",
  "LOGISTICS_NOTE",
] as const;

export const SERVER_ONLY_ACTIONS = [
  "SEND_EMAIL",
  "DRIVE_UPLOAD",
  "CALENDAR_CREATE",
  "CALENDAR_UPDATE",
  "PAYMENT",
  "FINAL_RESERVATION_CONFIRM",
  "OFFICIAL_NUMBERING",
  "EXTERNAL_API_ACTION",
] as const;

export const EXTERNAL_JOB_TYPES = [
  "EMAIL_SEND",
  "DRIVE_UPLOAD",
  "DRIVE_FOLDER_CREATE",
  "CALENDAR_CREATE",
  "CALENDAR_UPDATE",
  "CALENDAR_DELETE",
] as const;

export type OfflineResourceType = (typeof OFFLINE_RESOURCE_TYPES)[number];
export type ServerOnlyAction = (typeof SERVER_ONLY_ACTIONS)[number];
export type ExternalJobType = (typeof EXTERNAL_JOB_TYPES)[number];
export type OperationAction = "CREATE" | "UPDATE" | "ARCHIVE";
export type OperationSyncStatus = "PENDING" | "SYNCING" | "SYNCED" | "ERROR" | "CONFLICT" | "BLOCKED";
export type ExternalJobStatus = "QUEUED" | "RUNNING" | "SUCCESS" | "RETRYING" | "FAILED" | "BLOCKED_AUTH";
export type BatchResultStatus = "SUCCESS" | "CONFLICT" | "ERROR" | "BLOCKED";
export type DegradedReason = "ONLINE" | "NO_INTERNET" | "SERVER_DOWN" | "GOOGLE_DOWN" | "EMAIL_DOWN" | "AUTH_EXPIRED" | "PARTIAL_DEGRADED_MODE";

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = { [key: string]: JsonValue };

export type OperationEnvelope<TPayload extends JsonObject = JsonObject> = {
  operation_id: string;
  idempotency_key: string;
  organization_id: string;
  actor_user_id: string;
  resource_type: OfflineResourceType;
  resource_local_id: string;
  resource_server_id: string | null;
  action: OperationAction;
  payload: TPayload;
  base_snapshot?: JsonObject | null;
  server_snapshot?: JsonObject | null;
  base_version: number | null;
  created_at_local: string;
  queued_at: string;
  retry_count: number;
  sync_status: OperationSyncStatus;
  last_error_code: string | null;
  last_error_at: string | null;
};

export type OperationBatchResult = {
  operation_id: string;
  idempotency_key: string;
  status: BatchResultStatus;
  resource_server_id?: string;
  server_version?: number;
  error_code?: string;
  safe_message?: string;
  server_snapshot?: JsonObject;
  retryable?: boolean;
};

export type ExternalJobEnvelope<TPayload extends JsonObject = JsonObject> = {
  job_id: string;
  idempotency_key: string;
  organization_id: string;
  actor_user_id: string;
  client_slug: string;
  operation_id: string | null;
  job_type: ExternalJobType;
  payload: TPayload;
  status: ExternalJobStatus;
  retry_count: number;
  next_attempt_at: string | null;
  last_error_code: string | null;
  last_error_at: string | null;
  created_at: string;
};

export type SyncStatusSnapshot = {
  status: "SYNCED" | "OFFLINE" | "PENDING" | "SYNCING" | "ATTENTION";
  pending: number;
  syncing: number;
  errors: number;
  conflicts: number;
  blocked: number;
  synced: number;
  degradedReason: DegradedReason;
};

export type SyncAreaState = "OK" | "PENDIENTE" | "SINCRONIZANDO" | "ERROR" | "REQUIERE_AUTORIZACION";
export type SyncArea = {
  key: "orbit" | "clients" | "quotes" | "reservations" | "expenses" | "documents" | "drive" | "calendar" | "email" | "other";
  label: string;
  state: SyncAreaState;
  pending?: number;
  detail?: string;
};

export type BatchTransport = {
  send(operations: readonly OperationEnvelope[]): Promise<readonly OperationBatchResult[]>;
};

export type BlobRecord = {
  blob_id: string;
  organization_id: string;
  actor_user_id: string;
  operation_id: string;
  filename: string;
  mime_type: string;
  size: number;
  blob: Blob;
  upload_status: "PENDING" | "UPLOADING" | "UPLOADED" | "ERROR" | "BLOCKED";
  retry_count: number;
  last_error_at: string | null;
  server_reference: string | null;
  created_at: string;
};

export type FileUploadTransport = {
  upload(record: BlobRecord): Promise<{ serverReference: string }>;
};

export type ResourceIdMapping = {
  organization_id: string;
  actor_user_id: string;
  resource_type: OfflineResourceType;
  resource_local_id: string;
  resource_server_id: string;
  mapped_at: string;
};
