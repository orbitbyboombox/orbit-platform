import { randomUUID } from "./uuid.js";
import { RETRY_DELAYS_MS, retryDecision } from "./retry.js";
import type {
  BatchTransport,
  JsonObject,
  JsonValue,
  OfflineResourceType,
  OperationAction,
  OperationBatchResult,
  OperationEnvelope,
  SyncStatusSnapshot,
} from "./types.js";
import type { OrbitLocalStore } from "./local-store.js";
import { assertEnvelopeScope, assertOperationEnvelope } from "./validation.js";

type EnqueueInput = {
  resourceType: OfflineResourceType;
  resourceLocalId?: string;
  resourceServerId?: string | null;
  action: OperationAction;
  payload: JsonObject;
  baseSnapshot?: JsonObject | null;
  baseVersion?: number | null;
  idempotencyKey?: string;
  now?: Date;
};

function replaceLocalReference(value: JsonValue, localId: string, serverId: string): JsonValue {
  if (value === localId) return serverId;
  if (Array.isArray(value)) return value.map((item) => replaceLocalReference(item, localId, serverId));
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, replaceLocalReference(item, localId, serverId)]));
  return value;
}

function containsReference(value: JsonValue, ids: ReadonlySet<string>): boolean {
  if (typeof value === "string") return ids.has(value);
  if (Array.isArray(value)) return value.some((item) => containsReference(item, ids));
  if (value && typeof value === "object") return Object.values(value).some((item) => containsReference(item, ids));
  return false;
}

export class OrbitSyncQueueManager {
  private activeSync: Promise<SyncStatusSnapshot> | null = null;
  private online = true;
  private degradedReason: SyncStatusSnapshot["degradedReason"] = "ONLINE";

  constructor(
    readonly organizationId: string,
    readonly actorUserId: string,
    private readonly store: OrbitLocalStore,
    private readonly transport: BatchTransport,
  ) {}

  setConnectionState(online: boolean, reason: SyncStatusSnapshot["degradedReason"] = online ? "ONLINE" : "NO_INTERNET") {
    this.online = online;
    this.degradedReason = reason;
  }

  async enqueue(input: EnqueueInput) {
    const now = input.now ?? new Date();
    const operationId = randomUUID();
    const localId = input.resourceLocalId ?? randomUUID();
    const operation: OperationEnvelope = {
      operation_id: operationId,
      idempotency_key: input.idempotencyKey ?? `${this.organizationId}:${this.actorUserId}:${operationId}`,
      organization_id: this.organizationId,
      actor_user_id: this.actorUserId,
      resource_type: input.resourceType,
      resource_local_id: localId,
      resource_server_id: input.resourceServerId ?? null,
      action: input.action,
      payload: input.payload,
      base_snapshot: input.baseSnapshot ?? null,
      server_snapshot: null,
      base_version: input.baseVersion ?? null,
      created_at_local: now.toISOString(),
      queued_at: now.toISOString(),
      retry_count: 0,
      sync_status: "PENDING",
      last_error_code: null,
      last_error_at: null,
    };
    assertOperationEnvelope(operation);
    await this.store.putOperation(operation);
    return operation;
  }

  async getStatus(): Promise<SyncStatusSnapshot> {
    const operations = await this.store.listOperations();
    const count = (status: OperationEnvelope["sync_status"]) => operations.filter((operation) => operation.sync_status === status).length;
    const pending = count("PENDING");
    const syncing = count("SYNCING");
    const errors = count("ERROR");
    const conflicts = count("CONFLICT");
    const blocked = count("BLOCKED");
    const status = !this.online ? "OFFLINE" : conflicts + blocked + errors > 0 ? "ATTENTION" : syncing > 0 ? "SYNCING" : pending > 0 ? "PENDING" : "SYNCED";
    return { status, pending, syncing, errors, conflicts, blocked, synced: count("SYNCED"), degradedReason: this.degradedReason };
  }

  syncNow() {
    if (this.activeSync) return this.activeSync;
    this.activeSync = this.runSync(true).finally(() => { this.activeSync = null; });
    return this.activeSync;
  }

  syncDue() {
    if (this.activeSync) return this.activeSync;
    this.activeSync = this.runSync(false).finally(() => { this.activeSync = null; });
    return this.activeSync;
  }

  private async runSync(manual: boolean) {
    if (!this.online) return this.getStatus();
    const operations = await this.store.listOperations(["PENDING", "ERROR"]);
    const now = Date.now();
    const retryDue = (operation: OperationEnvelope) => operation.sync_status === "PENDING" || manual || !operation.last_error_at || now >= Date.parse(operation.last_error_at) + (RETRY_DELAYS_MS[Math.max(0, operation.retry_count - 1)] ?? Number.POSITIVE_INFINITY);
    const remaining = new Set(operations.filter((operation) => operation.retry_count < 4 && retryDue(operation)).map((operation) => operation.operation_id));
    const failedLocalIds = new Set<string>();
    let transportFailed = false;
    while (remaining.size > 0) {
      const current = (await this.store.listOperations()).filter((operation) => remaining.has(operation.operation_id));
      for (const operation of current.filter((item) => containsReference(item.payload, failedLocalIds))) {
        await this.store.putOperation({ ...operation, sync_status: "BLOCKED", last_error_code: "DEPENDENCY_UNRESOLVED", last_error_at: new Date().toISOString() });
        remaining.delete(operation.operation_id);
      }
      const waiting = (await this.store.listOperations()).filter((operation) => remaining.has(operation.operation_id));
      if (waiting.length === 0) break;
      const localIds = new Set(waiting.map((operation) => operation.resource_local_id));
      const eligible = waiting.filter((operation) => !containsReference(operation.payload, localIds));
      if (eligible.length === 0) {
        for (const operation of waiting) await this.store.putOperation({ ...operation, sync_status: "BLOCKED", last_error_code: "DEPENDENCY_CYCLE", last_error_at: new Date().toISOString() });
        break;
      }
      for (const operation of eligible) {
        assertEnvelopeScope(operation, this.organizationId, this.actorUserId);
        await this.store.putOperation({ ...operation, sync_status: "SYNCING" });
      }
      let results: readonly OperationBatchResult[];
      try {
        results = await this.transport.send(eligible);
      } catch {
        const failedAt = new Date();
        for (const operation of eligible) {
          const retry = retryDecision(operation.retry_count, failedAt);
          await this.store.putOperation({ ...operation, retry_count: operation.retry_count + 1, sync_status: retry.retry ? "ERROR" : "BLOCKED", last_error_code: "SERVER_DOWN", last_error_at: failedAt.toISOString() });
          failedLocalIds.add(operation.resource_local_id);
          remaining.delete(operation.operation_id);
        }
        this.degradedReason = "SERVER_DOWN";
        transportFailed = true;
        continue;
      }
      const byOperation = new Map(results.map((result) => [result.operation_id, result]));
      for (const operation of eligible) {
        await this.applyResult(operation, byOperation.get(operation.operation_id));
        const updated = await this.store.getOperation(operation.operation_id);
        if (updated?.sync_status !== "SYNCED") failedLocalIds.add(operation.resource_local_id);
        remaining.delete(operation.operation_id);
      }
    }
    this.degradedReason = transportFailed ? "SERVER_DOWN" : "ONLINE";
    return this.getStatus();
  }

  async retryErrors() {
    const errors = await this.store.listOperations(["ERROR"]);
    for (const operation of errors) await this.store.putOperation({ ...operation, sync_status: "PENDING", retry_count: 0, last_error_code: null, last_error_at: null });
    return this.syncNow();
  }

  private async applyResult(operation: OperationEnvelope, result?: OperationBatchResult) {
    const at = new Date().toISOString();
    if (!result) {
      await this.store.putOperation({ ...operation, retry_count: operation.retry_count + 1, sync_status: "ERROR", last_error_code: "MISSING_BATCH_RESULT", last_error_at: at });
      return;
    }
    if (result.status === "SUCCESS") {
      const serverId = result.resource_server_id ?? operation.resource_server_id;
      await this.store.putOperation({ ...operation, resource_server_id: serverId ?? null, base_version: result.server_version ?? operation.base_version, sync_status: "SYNCED", last_error_code: null, last_error_at: null });
      if (serverId) await this.mapResource(operation, serverId);
      return;
    }
    const status = result.status === "CONFLICT" ? "CONFLICT" : result.status === "BLOCKED" ? "BLOCKED" : "ERROR";
    await this.store.putOperation({ ...operation, base_version: result.server_version ?? operation.base_version, server_snapshot: result.server_snapshot ?? operation.server_snapshot ?? null, retry_count: result.retryable ? operation.retry_count + 1 : operation.retry_count, sync_status: status, last_error_code: result.error_code ?? result.status, last_error_at: at });
  }

  private async mapResource(operation: OperationEnvelope, serverId: string) {
    await this.store.putMapping({ organization_id: this.organizationId, actor_user_id: this.actorUserId, resource_type: operation.resource_type, resource_local_id: operation.resource_local_id, resource_server_id: serverId, mapped_at: new Date().toISOString() });
    const pending = await this.store.listOperations(["PENDING", "ERROR", "CONFLICT", "BLOCKED"]);
    for (const queued of pending) {
      if (queued.operation_id === operation.operation_id) continue;
      const payload = replaceLocalReference(queued.payload, operation.resource_local_id, serverId) as JsonObject;
      if (JSON.stringify(payload) !== JSON.stringify(queued.payload)) await this.store.putOperation({ ...queued, payload });
    }
  }

  async resolveConflict(operationId: string, resolution: "SERVER" | "LOCAL", payload?: JsonObject, baseVersion?: number) {
    const operation = await this.store.getOperation(operationId);
    if (!operation || operation.sync_status !== "CONFLICT") throw new Error("CONFLICT_NOT_FOUND");
    if (resolution === "SERVER") {
      await this.store.putOperation({ ...operation, payload: operation.server_snapshot ?? operation.payload, sync_status: "SYNCED", last_error_code: null, last_error_at: null });
      return;
    }
    if (!payload || baseVersion === undefined) throw new Error("CONFLICT_RESOLUTION_REQUIRED");
    await this.store.putOperation({ ...operation, payload, base_snapshot: operation.server_snapshot ?? operation.base_snapshot ?? null, server_snapshot: null, base_version: baseVersion, sync_status: "PENDING", retry_count: 0, last_error_code: null, last_error_at: null });
  }
}
