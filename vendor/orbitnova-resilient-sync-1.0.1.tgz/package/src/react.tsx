"use client";

import type { CSSProperties } from "react";
import type { SyncArea, SyncStatusSnapshot } from "./types.js";

const palette = { orange: "#ff8a00", green: "#65d49a", red: "#ff7a7a", muted: "#9ca3af", panel: "#111318", border: "#2a2f38", text: "#f5f7fa" };
const stateColor = (state: SyncArea["state"]) => state === "OK" ? palette.green : state === "ERROR" ? palette.red : state === "REQUIERE_AUTORIZACION" ? palette.orange : palette.muted;

export function OrbitSyncStatusIndicator({ snapshot, onSyncNow }: { snapshot: SyncStatusSnapshot; onSyncNow?: () => void }) {
  const copy = snapshot.status === "SYNCED" ? "TODO SINCRONIZADO ✓" : snapshot.status === "OFFLINE" ? `MODO OFFLINE · ${snapshot.pending} CAMBIOS PENDIENTES` : snapshot.status === "SYNCING" ? `SINCRONIZANDO · ${snapshot.syncing}` : snapshot.status === "ATTENTION" ? `${snapshot.errors + snapshot.conflicts + snapshot.blocked} CAMBIO REQUIERE ATENCIÓN` : `${snapshot.pending} CAMBIOS PENDIENTES`;
  return <div aria-live="polite" style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", color: palette.text }}>
    <span style={{ width: 9, height: 9, borderRadius: 99, background: snapshot.status === "SYNCED" ? palette.green : snapshot.status === "ATTENTION" ? palette.red : palette.orange }} />
    <strong style={{ fontSize: 12, letterSpacing: ".08em" }}>{copy}</strong>
    {onSyncNow && snapshot.status !== "SYNCED" ? <button type="button" onClick={onSyncNow} style={buttonStyle}>SINCRONIZAR AHORA</button> : null}
  </div>;
}

export function OrbitSyncCenter({ areas, snapshot, onSyncNow, onRetryAll }: { areas: readonly SyncArea[]; snapshot: SyncStatusSnapshot; onSyncNow: () => void; onRetryAll?: () => void }) {
  return <section aria-labelledby="orbit-sync-center-title" style={{ background: palette.panel, border: `1px solid ${palette.border}`, borderRadius: 16, color: palette.text, padding: 18, maxWidth: 680 }}>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
      <div><small style={{ color: palette.orange, letterSpacing: ".16em", fontWeight: 800 }}>ORBIT RESILIENT SYNC</small><h2 id="orbit-sync-center-title" style={{ margin: "5px 0 0", fontSize: 20 }}>SYNC CENTER</h2></div>
      <OrbitSyncStatusIndicator snapshot={snapshot} onSyncNow={onSyncNow} />
    </div>
    <div style={{ display: "grid", gap: 8, marginTop: 16 }}>
      {areas.map((area) => <div key={area.key} style={{ display: "grid", gridTemplateColumns: "minmax(120px,1fr) auto", gap: 12, padding: "10px 0", borderTop: `1px solid ${palette.border}` }}>
        <span>{area.label}{area.pending ? ` · ${area.pending}` : ""}</span>
        <strong style={{ color: stateColor(area.state), fontSize: 12 }}>{area.state.replaceAll("_", " ")}</strong>
        {area.detail ? <small style={{ color: palette.muted, gridColumn: "1 / -1" }}>{area.detail}</small> : null}
      </div>)}
    </div>
    {onRetryAll ? <button type="button" onClick={onRetryAll} style={{ ...buttonStyle, marginTop: 14 }}>REINTENTAR TODO</button> : null}
  </section>;
}

const buttonStyle: CSSProperties = { border: `1px solid ${palette.orange}`, color: palette.text, background: "transparent", borderRadius: 9, padding: "8px 11px", fontWeight: 800, fontSize: 11, cursor: "pointer" };
