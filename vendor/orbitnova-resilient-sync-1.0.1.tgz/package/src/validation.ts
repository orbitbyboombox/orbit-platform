import {
  OFFLINE_RESOURCE_TYPES,
  type ExternalJobEnvelope,
  type OperationEnvelope,
  type OperationSyncStatus,
} from "./types.js";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const IDEMPOTENCY = /^[A-Za-z0-9][A-Za-z0-9:_./-]{7,199}$/;
const OPERATION_STATUSES = new Set<OperationSyncStatus>(["PENDING", "SYNCING", "SYNCED", "ERROR", "CONFLICT", "BLOCKED"]);

export function isUuid(value: unknown): value is string {
  return typeof value === "string" && UUID.test(value);
}

export function isIsoDate(value: unknown): value is string {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}

export function assertOperationEnvelope(value: unknown): asserts value is OperationEnvelope {
  if (!value || typeof value !== "object") throw new Error("INVALID_OPERATION");
  const operation = value as Partial<OperationEnvelope>;
  if (!isUuid(operation.operation_id) || !isUuid(operation.organization_id) || !isUuid(operation.actor_user_id)) throw new Error("INVALID_OPERATION_IDENTITY");
  if (!operation.idempotency_key || !IDEMPOTENCY.test(operation.idempotency_key)) throw new Error("INVALID_IDEMPOTENCY_KEY");
  if (!OFFLINE_RESOURCE_TYPES.includes(operation.resource_type as never)) throw new Error("RESOURCE_NOT_OFFLINE_CAPABLE");
  if (!operation.resource_local_id || operation.resource_local_id.length > 200) throw new Error("INVALID_LOCAL_RESOURCE_ID");
  if (operation.resource_server_id !== null && !isUuid(operation.resource_server_id)) throw new Error("INVALID_SERVER_RESOURCE_ID");
  if (operation.action !== "CREATE" && operation.action !== "UPDATE" && operation.action !== "ARCHIVE") throw new Error("ACTION_NOT_OFFLINE_CAPABLE");
  if (!operation.payload || Array.isArray(operation.payload) || typeof operation.payload !== "object") throw new Error("INVALID_OPERATION_PAYLOAD");
  if (operation.base_version !== null && (operation.base_version === undefined || !Number.isInteger(operation.base_version) || operation.base_version < 0)) throw new Error("INVALID_BASE_VERSION");
  if (!isIsoDate(operation.created_at_local) || !isIsoDate(operation.queued_at)) throw new Error("INVALID_OPERATION_TIMESTAMP");
  if (operation.retry_count === undefined || !Number.isInteger(operation.retry_count) || operation.retry_count < 0) throw new Error("INVALID_RETRY_COUNT");
  if (!operation.sync_status || !OPERATION_STATUSES.has(operation.sync_status)) throw new Error("INVALID_SYNC_STATUS");
}

export function assertEnvelopeScope(operation: OperationEnvelope, organizationId: string, actorUserId: string) {
  if (operation.organization_id !== organizationId) throw new Error("CROSS_TENANT_BLOCKED");
  if (operation.actor_user_id !== actorUserId) throw new Error("ACTOR_MISMATCH");
}

export function assertExternalJobEnvelope(job: ExternalJobEnvelope) {
  if (!isUuid(job.job_id) || !isUuid(job.organization_id) || !isUuid(job.actor_user_id)) throw new Error("INVALID_JOB_IDENTITY");
  if (!IDEMPOTENCY.test(job.idempotency_key)) throw new Error("INVALID_IDEMPOTENCY_KEY");
}

export function safeSyncMessage(code: string) {
  const messages: Record<string, string> = {
    NO_INTERNET: "Guardamos tu cambio. Se sincronizará cuando vuelva la conexión.",
    SERVER_DOWN: "Guardamos tu cambio. ORBIT lo sincronizará cuando el servicio vuelva.",
    AUTH_EXPIRED: "Reconecta tu cuenta para completar las tareas pendientes.",
    CONFLICT: "Este registro cambió mientras estabas sin conexión.",
    ADAPTER_NOT_CONFIGURED: "Este módulo aún no está habilitado para sincronización.",
  };
  return messages[code] ?? "No pudimos sincronizar este cambio. Puedes reintentarlo sin perder tus datos.";
}
