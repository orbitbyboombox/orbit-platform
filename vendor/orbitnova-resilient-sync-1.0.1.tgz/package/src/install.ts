import { IndexedDbOrbitLocalStore, type OrbitLocalStore } from "./local-store.js";
import { OrbitSyncQueueManager } from "./queue-manager.js";
import type { BatchTransport, OfflineResourceType } from "./types.js";
import { OrbitOfflineFileQueue } from "./file-queue.js";

export type OrbitResilientSyncOptions = {
  organizationId: string;
  userId: string;
  adapters: { transport: BatchTransport; store?: OrbitLocalStore; fileUpload?: import("./types.js").FileUploadTransport };
  resources: readonly OfflineResourceType[];
  autoSync?: boolean;
};

export function installOrbitResilientSync(options: OrbitResilientSyncOptions) {
  const enabled = new Set(options.resources);
  const store = options.adapters.store ?? new IndexedDbOrbitLocalStore(options.organizationId, options.userId);
  const manager = new OrbitSyncQueueManager(options.organizationId, options.userId, store, options.adapters.transport);
  const files = options.adapters.fileUpload ? new OrbitOfflineFileQueue(options.organizationId, options.userId, store, options.adapters.fileUpload) : null;
  let removeListeners = () => undefined;
  if (typeof window !== "undefined") {
    const update = () => { manager.setConnectionState(window.navigator.onLine, window.navigator.onLine ? "ONLINE" : "NO_INTERNET"); if (window.navigator.onLine && options.autoSync !== false) { void manager.syncDue(); void files?.syncNow(); } };
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    const interval = options.autoSync === false ? null : window.setInterval(() => { if (window.navigator.onLine) { void manager.syncDue(); void files?.syncNow(); } }, 60_000);
    update();
    removeListeners = () => { window.removeEventListener("online", update); window.removeEventListener("offline", update); if (interval !== null) window.clearInterval(interval); };
  }
  return {
    manager,
    enabledResources: enabled,
    enqueue: (input: Parameters<OrbitSyncQueueManager["enqueue"]>[0]) => {
      if (!enabled.has(input.resourceType)) throw new Error("RESOURCE_NOT_ENABLED");
      return manager.enqueue(input);
    },
    syncNow: () => manager.syncNow(),
    retryErrors: () => manager.retryErrors(),
    queueFile: files ? (input: Parameters<OrbitOfflineFileQueue["enqueue"]>[0]) => files.enqueue(input) : undefined,
    syncFiles: files ? () => files.syncNow() : undefined,
    releaseUploadedFile: files ? (blobId: string) => files.releaseUploaded(blobId) : undefined,
    retryFile: files ? (blobId: string) => files.retry(blobId) : undefined,
    status: () => manager.getStatus(),
    logout: async () => { removeListeners(); },
    clearLocalData: async () => { await store.clearUserData(); },
    listOperations: () => store.listOperations(),
    listFiles: () => store.listBlobs(),
    destroy: removeListeners,
  };
}
