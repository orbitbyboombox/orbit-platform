import type { SyncArea, SyncAreaState } from "./types.js";

type OperationProjection = { resource_type: string; sync_status: string };
type JobProjection = { job_type: string; status: string };

const stateFor = (states: readonly string[]): SyncAreaState => {
  if (states.some((state) => state === "BLOCKED_AUTH")) return "REQUIERE_AUTORIZACION";
  if (states.some((state) => state === "ERROR" || state === "CONFLICT" || state === "BLOCKED" || state === "FAILED")) return "ERROR";
  if (states.some((state) => state === "SYNCING" || state === "RUNNING")) return "SINCRONIZANDO";
  if (states.some((state) => state === "PENDING" || state === "QUEUED" || state === "RETRYING")) return "PENDIENTE";
  return "OK";
};

export function buildSyncAreas(operations: readonly OperationProjection[], jobs: readonly JobProjection[]): SyncArea[] {
  const operationStates = (types: readonly string[]) => operations.filter((item) => types.includes(item.resource_type)).map((item) => item.sync_status);
  const jobStates = (types: readonly string[]) => jobs.filter((item) => types.includes(item.job_type)).map((item) => item.status);
  const area = (key: SyncArea["key"], label: string, states: string[]): SyncArea => ({ key, label, state: stateFor(states), pending: states.filter((state) => !["SYNCED", "SUCCESS"].includes(state)).length || undefined });
  return [
    area("orbit", "Datos ORBIT", operations.map((item) => item.sync_status)),
    area("clients", "Clientes", operationStates(["CLIENT"])),
    area("quotes", "Cotizaciones", operationStates(["QUOTE_DRAFT"])),
    area("reservations", "Reservas y eventos", operationStates(["RESERVATION_DRAFT", "EVENT_DRAFT"])),
    area("expenses", "Gastos", operationStates(["EXPENSE"])),
    area("documents", "Documentos", jobStates(["DRIVE_UPLOAD"])),
    area("drive", "Drive", jobStates(["DRIVE_UPLOAD", "DRIVE_FOLDER_CREATE"])),
    area("calendar", "Calendar", jobStates(["CALENDAR_CREATE", "CALENDAR_UPDATE", "CALENDAR_DELETE"])),
    area("email", "Email", jobStates(["EMAIL_SEND"])),
  ];
}
