import type { JsonObject, JsonValue } from "./types.js";

export type FieldConflict = { field: string; base: JsonValue | undefined; local: JsonValue | undefined; server: JsonValue | undefined };
export type MergeResult = { merged: JsonObject; conflicts: FieldConflict[]; autoMerged: boolean };

const same = (left: JsonValue | undefined, right: JsonValue | undefined) => JSON.stringify(left) === JSON.stringify(right);

export function mergeNonCollidingChanges(base: JsonObject, local: JsonObject, server: JsonObject): MergeResult {
  const merged: JsonObject = { ...server };
  const conflicts: FieldConflict[] = [];
  const fields = new Set([...Object.keys(base), ...Object.keys(local), ...Object.keys(server)]);
  for (const field of fields) {
    const baseValue = base[field];
    const localValue = local[field];
    const serverValue = server[field];
    const localChanged = !same(localValue, baseValue);
    const serverChanged = !same(serverValue, baseValue);
    if (localChanged && serverChanged && !same(localValue, serverValue)) {
      conflicts.push({ field, base: baseValue, local: localValue, server: serverValue });
      continue;
    }
    if (localChanged) {
      if (localValue === undefined) delete merged[field];
      else merged[field] = localValue;
    }
  }
  return { merged, conflicts, autoMerged: conflicts.length === 0 };
}
